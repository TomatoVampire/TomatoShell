StupidShell
-------------------------
------------------------------------------------------------------------


ABSTRACT
------------------------------------------------------------------------
A simple implementation of a shell in C , a DIY shell . It is a part of a special on my website(www.tomorrow.wiki/archives/tag/stupidshell), which demonstrates briefly how a shell works .



DESCRIPTION
------------------------------------------------------------------------
Features:

-dynamic prompt 

-complicated commands ,like: grep str <a.txt>b.txt

-piping

-redirection

-only builtins commands : cd , help ,exit


There are many limitations and bugs in this project. Someone who is interested in it should fork it and play with it . It would be a good beginning to explore how a shell and operating system work.  



INSTALLATION
------------------------------------------------------------------------
Download the project and use command make to build the executable file stupidshell .



BESIDES
------------------------------------------------------------------------
Welcome to the website(www.tomorrow.wiki or www.tomorrow.wiki/archives/tag/stupidshell) to explore more information about this project.

Contact with me : 1107150012@qq.com
